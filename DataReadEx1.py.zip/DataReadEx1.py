#program for Reading value and display
print("Enter Any Value")
a=input()
print("a={}, Type={}".format(a,type(a)))
