#program for adding of two numerical values
a=float(input("Enter value of a:"))
b=float(input("Enter value of b:"))
c=a+b
print("*********************")
print("Val of a=",a)
print("val of b=",b)
print("sum({},{})={}".format(a,b,c))
print("*********************")
